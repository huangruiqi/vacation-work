$(function(){
	// 点击标题
	$("a:eq(1)").hover(function(){
		$("a:eq(1)").removeClass("titleone");
		$("a:eq(1)").addClass("titleonechange");
	},function(){
		$("a:eq(1)").removeClass("titleonechange");
		$("a:eq(1)").addClass("titleone");
	});
	$("a:eq(2)").hover(function(){
		$("a:eq(2)").removeClass("titleone");
		$("a:eq(2)").addClass("titleonechange");
	},function(){
		$("a:eq(2)").removeClass("titleonechange");
		$("a:eq(2)").addClass("titleone");
	});
	$("a:eq(3)").hover(function(){
		$("a:eq(3)").removeClass("titleone");
		$("a:eq(3)").addClass("titleonechange");
	},function(){
		$("a:eq(3)").removeClass("titleonechange");
		$("a:eq(3)").addClass("titleone");
	});
	$("a:eq(4)").hover(function(){
		$("a:eq(4)").removeClass("titleone");
		$("a:eq(4)").addClass("titleonechange");
	},function(){
		$("a:eq(4)").removeClass("titleonechange");
		$("a:eq(4)").addClass("titleone");
	});







	// 左右箭头
	var i=9;
	var j=15;
	function Show(){
		$('img').eq(i).fadeIn(100).
  		siblings('img').fadeOut(0);
  		$('img').removeClass('cssone');
		$('img').eq(j).addClass('cssone');	
  	}
  	Show();
  	$(".jiantouleft").click(function(){
		
		if(i==9)
			{i=15;}
		i--;
		j=i+6
		Show();
	});
	$(".jiantouright").click(function(){
		
		if(i==14)
			{i=8;}
		i++;
		j=i+6;
		Show();
	});
	// 轮播效果
	var timer;
	function showTime(){
    	timer = setInterval(function(){
    	$(".jiantouright").click();
  		},2000);
	}
	// Show();
	showTime();
	// 点击缩略图切换图
	$("#boxa").hover(function(){
		clearInterval(timer);
		i=9;
		$("img:gt(8)").removeClass("cssone");
		$("img:eq(15)").addClass("cssone");	
		$("img:eq(9)").fadeIn(500);	
		$(".boxthree img").eq(0).siblings("img").hide();
	},function(){
	 	showTime();
	});
	$("#boxb").hover(function(){
		clearInterval(timer);
		i=10;
		$("img:gt(8)").removeClass("cssone");
		$("img:eq(16)").addClass("cssone");	
		$("img:eq(10)").fadeIn(500);	
		$(".boxthree img").eq(1).siblings("img").hide();
	},function(){
	 	showTime();
	});
	$("#boxc").hover(function(){
		clearInterval(timer);
		i=11;
		$("img:gt(8)").removeClass("cssone");
		$("img:eq(17)").addClass("cssone");	
		$("img:eq(11)").fadeIn(500);	
		$(".boxthree img").eq(2).siblings("img").hide();
	},function(){
	 	showTime();
	});
	$("#boxd").hover(function(){
		clearInterval(timer);
		i=12;
		$("img:gt(8)").removeClass("cssone");
		$("img:eq(18)").addClass("cssone");	
		$("img:eq(12)").fadeIn(500);	
		$(".boxthree img").eq(3).siblings("img").hide();
	},function(){
	 	showTime();
	});
	$("#boxe").hover(function(){
		clearInterval(timer);
		i=13;
		$("img:gt(8)").removeClass("cssone");
		$("img:eq(19)").addClass("cssone");	
		$("img:eq(13)").fadeIn(500);	
		$(".boxthree img").eq(4).siblings("img").hide();
	},function(){
	 	showTime();
	});
	$("#boxf").hover(function(){
		clearInterval(timer);
		i=14;
		$("img:gt(8)").removeClass("cssone");
		$("img:eq(20)").addClass("cssone");	
		$("img:eq(14)").fadeIn(500);	
		$(".boxthree img").eq(5).siblings("img").hide();
	},function(){
	 	showTime();
	});



	// fashion show
	// 左右箭头
	var a=25;
	function Showtwo(){
		$('img').eq(a).fadeIn(100).
  		siblings('img').fadeOut(0);	
  	}
  	Showtwo();
  	$(".jiantoutwoleft").click(function(){
		
		if(a==25)
			{a=30;}
		a--;
		Showtwo();
	});
	$(".jiantoutworight").click(function(){
		
		if(a==29)
			{a=24;}
		a++;
		Showtwo();
	});
	// 小轮播效果
	var timertwo;
	function showTimetwo(){
    	timertwo = setInterval(function(){
    	$(".jiantoutworight").click();
  		},2000);
	}
	showTimetwo();
	// click出现事件
	$("#more").hover(function(){
		$("div:eq(73)").removeClass("none");
	},function(){
		$("div:eq(73)").addClass("none");
	});
	$(".introduce").hover(function(){
		$("div:eq(73)").removeClass("none");
		$("a:eq(31)").removeClass("opa");	
	},function(){
		$("div:eq(73)").addClass("none");
		$("a:eq(31)").addClass("opa");
	});
	$("#moreone").hover(function(){
		$("div:eq(74)").removeClass("none");
		$("a:eq(32)").removeClass("opa");	
	},function(){
		$("div:eq(74)").addClass("none");
		$("a:eq(32)").addClass("opa");
	});
	$("#BI").hover(function(){
		$("div:eq(74)").removeClass("none");	
	},function(){
		$("div:eq(74)").addClass("none");
	});
	$("#moretwo").hover(function(){
		$("div:eq(75)").removeClass("none");
		$("a:eq(33)").removeClass("opa");	
	},function(){
		$("div:eq(75)").addClass("none");
		$("a:eq(33)").addClass("opa");
	});
	$("#Works").hover(function(){
		$("div:eq(75)").removeClass("none");	
	},function(){
		$("div:eq(75)").addClass("none");
	});
	$("#morethree").hover(function(){
		$("div:eq(76)").removeClass("none");
		$("a:eq(34)").removeClass("opa");	
	},function(){
		$("div:eq(76)").addClass("none");
		$("a:eq(34)").addClass("opa");
	});
	$("#FS").hover(function(){
		$("div:eq(76)").removeClass("none");	
	},function(){
		$("div:eq(76)").addClass("none");
	});
	$("#morefour").hover(function(){
		$("div:eq(79)").removeClass("none");	
		$("a:eq(35)").removeClass("opa");
	},function(){
		$("div:eq(79)").addClass("none");
		$("a:eq(35)").addClass("opa");
	});
	$("#Awards").hover(function(){
		$("div:eq(79)").removeClass("none");	
	},function(){
		$("div:eq(79)").addClass("none");
	});
	
	$("#morefive").hover(function(){
		$("a:eq(36)").removeClass("opa");
	},function(){
		$("a:eq(36)").addClass("opa");
	});
	$("#moresix").hover(function(){
		$("a:eq(37)").removeClass("opa");
	},function(){
		$("a:eq(37)").addClass("opa");
	});
	$("#moreseven").hover(function(){
		$("a:eq(38)").removeClass("opa");
	},function(){
		$("a:eq(38)").addClass("opa");
	});
	// 注册验证
	var Div=document.getElementsByTagName('div');
	var mask=Div[26];
	var Input=document.getElementsByTagName('input');
	var Name=Input[8];
	var pwd=Input[9];
	var pwd2=Input[10];
	var button=Input[11];
	var buttona=Input[7]
	// var count=document.getElementsById("count");
	var aP=document.getElementsByTagName("p");
	var name_p=aP[3];
	var pwd_p=aP[4];
	var pwd2_p=aP[5];
	var name_length=0;

	// 测符号长度函数
	 function getLength(str){
  		return str.length;
 	}
 	// 关于name
 	function getByteLen(val) {  
           var len = 0;            
           for (var i = 0; i < val.length; i++) {
                      var a = val.charAt(i);   
                      if (a.match(/[^\x00-\xff]/ig) != null){   
                             len += 2;             
                      }else{      
                            len += 1;             
                   }        
            }            
        return len;   
    }
 	Name.onfocus=function(){
		name_p.style.display="block";
	}
	Name.onblur=function(){
	// var re=/[^\w\u4e00-\u9fa5]/g;
		name_length=getByteLen(this.value);
		if(name_length==0){
			name_p.innerHTML='不能为空';
			Name.className="false";
		}
		else if(name_length>16||name_length<4){
			name_p.innerHTML='长度错误';
			Name.className="false";
		}
		else{
			name_p.innerHTML='Pass!';
			Name.className="true";
		}
	}
	// 密码
	pwd.onfocus=function(){
		pwd_p.style.display="block";
	}	
	pwd.onkeyup=function(){
		pwd2_p.style.display="block";
	}  
	pwd.onblur=function(){
		// var litword=/^[a-z]+$/gi;
		// var num=/^[0-9]+$/gi;
		// var bigword=/^[A-Z]+$/gi;
		var litbignum=/^[0-9A-Za-z]+$/gi;
		// var numbig=/^[A-Z0-9]+$/gi;
		// var biglit=/^[A-Za-z]+$/gi;
		// var numlit=/^[a-z0-9]+$/gi;
		pwd_length=getLength(this.value);
		if(pwd_length==0){
			pwd_p.innerHTML='不能为空';
			pwd.className="false";
		}
		else if(pwd_length>16||pwd_length<4){
			pwd_p.innerHTML='长度错误';
			pwd.className="false";
		}
		else{
			
		
			if(litbignum.test(this.value)){
				// if(litword.test(this.value)){
				// 	pwd_p.innerHTML='亲还需要加上大写字母和数字哦';	
				// 	pwd.className="false";
				
				// }
				// else if(num.test(this.value)){
				// 	pwd_p.innerHTML='亲还需要加上大写和小写字母哦';
				// 	pwd.className="false";	
					
				// }
				// else if(bigword.test(this.value)){
				// 	pwd_p.innerHTML='亲还需要加上小写字母和数字哦';	
				// 	pwd.className="false";
					
				// }
				// else if(numbig.test(this.value)){
				// 	pwd_p.innerHTML='亲还需要加上小写字母哦';	
				// 	pwd.className="false";
					
				// }
				// else if( biglit.test(this.value)){
				// 	pwd_p.innerHTML='亲还需要加上数字哦';	
				// 	pwd.className="false";
					
				// }
				// else if(numlit.test(this.value)){
				// 	pwd_p.innerHTML='亲还需要加上大写字母哦';	
				// 	pwd.className="false";
					
				// }
				// else{
				// 	pwd_p.innerHTML='Pass!';
				// 	pwd.className="true";	
				// }	
				pwd_p.innerHTML='Pass!';
				pwd.className="true";
			}
			else{
				pwd_p.innerHTML='不在规定设置密码的规则内';	
				pwd.className="false";
			}	
		}
	}
	pwd2.onblur=function(){
		if(this.value!=pwd.value){
			pwd2_p.innerHTML=
			'两次输入密码不一致';	
			pwd2.className="false";
		}
		else{
			pwd2_p.innerHTML=
			'Pass!';
			pwd2.className="true";		
		}
	}
	button.onclick=function(){
		for(i=3;i<6;i++){
			if(aP[i].innerHTML!="Pass!"){
				alert("注册失败！！/(ㄒoㄒ)/~~");
				return;
			}
			else{
			}
		}
		alert("注册成功！！！O(∩_∩)O");
	}
	$(".register").click(function(){
		$("div:eq(83)").removeClass("none");
		$("div:eq(84)").removeClass("none");
	});
	$(".buttona").click(function(){
		$("div:eq(83)").addClass("none");
		$("div:eq(84)").addClass("none");	
	});
	$("#mask").click(function(){
		$("div:eq(83)").addClass("none");
		$("div:eq(84)").addClass("none");	
	});


	// 留言板
	$("#bbsmybut").click(function(){
		if($(".bbsmasktext").val() == ""){
		//判断是否为空
			alert("不能提交空内容！");
		}
		else{
			$(".ulone").append("<li>"+$("textarea").val()+"</li>");
			$(".bbsmasktext").val("");
			//清空输入框
		}

	});
	// if ($(".bbsmasktext").val()=="") {
	// 	console.log(11);
	// }
	// ;
	window.onscroll=function(){
		var t =document.documentElement.scrollTop||document.body.scrollTop;
		var boxfive =document.getElementById("boxfive");
		var login =document.getElementById("login");
		if (t>500&&t<2600) {
			boxfive.className="boxfivechange";
			login.className="loginchange";
		}
		else{
			boxfive.className="boxfive";
			login.className="login";
		}
	}

	// bottom的hover
	$("#eone").hover(function(){
		$("#eone").removeClass("bota");
		$("#eone").addClass("botachange");
	},function(){
		$("#eone").removeClass("botachange");
		$("#eone").addClass("bota");
	});
	$("#etwo").hover(function(){
		$("#etwo").removeClass("bota");
		$("#etwo").addClass("botachange");
	},function(){
		$("#etwo").removeClass("botachange");
		$("#etwo").addClass("bota");
	});
	$("#ethree").hover(function(){
		$("#ethree").removeClass("bota");
		$("#ethree").addClass("botachange");
	},function(){
		$("#ethree").removeClass("botachange");
		$("#ethree").addClass("bota");
	});
	$("#efour").hover(function(){
		$("#efour").removeClass("bota");
		$("#efour").addClass("botachange");
	},function(){
		$("#efour").removeClass("botachange");
		$("#efour").addClass("bota");
	});
	$("#wone").hover(function(){
		$("#wone").removeClass("bota");
		$("#wone").addClass("botachange");
	},function(){
		$("#wone").removeClass("botachange");
		$("#wone").addClass("bota");
	});
	$("#wtwo").hover(function(){
		$("#wtwo").removeClass("bota");
		$("#wtwo").addClass("botachange");
	},function(){
		$("#wtwo").removeClass("botachange");
		$("#wtwo").addClass("bota");
	});
	$("#wthree").hover(function(){
		$("#wthree").removeClass("bota");
		$("#wthree").addClass("botachange");
	},function(){
		$("#wthree").removeClass("botachange");
		$("#wthree").addClass("bota");
	});
	$("#wfour").hover(function(){
		$("#wfour").removeClass("bota");
		$("#wfour").addClass("botachange");
	},function(){
		$("#wfour").removeClass("botachange");
		$("#wfour").addClass("bota");
	});
	$("#qone").hover(function(){
		$("#qone").removeClass("bota");
		$("#qone").addClass("botachange");
	},function(){
		$("#qone").removeClass("botachange");
		$("#qone").addClass("bota");
	});
	$("#qtwo").hover(function(){
		$("#qtwo").removeClass("bota");
		$("#qtwo").addClass("botachange");
	},function(){
		$("#qtwo").removeClass("botachange");
		$("#qtwo").addClass("bota");
	});
	$("#qthree").hover(function(){
		$("#qthree").removeClass("bota");
		$("#qthree").addClass("botachange");
	},function(){
		$("#qthree").removeClass("botachange");
		$("#qthree").addClass("bota");
	});
	$("#qfour").hover(function(){
		$("#qfour").removeClass("bota");
		$("#qfour").addClass("botachange");
	},function(){
		$("#qfour").removeClass("botachange");
		$("#qfour").addClass("bota");
	});



	// JSON
	function showJSON() {
	var bbsmaskcon = document.getElementById("bbsmaskcon");
	// var json=JSON.parse(xhr.responseText);
	var str='';
	var post = { "content":[{ "people": "Brett","num":"21", "time":"2017-2-28", "postTit": "TITLE:哈哈哈同款手链" ,"postCon": "一天就到货了，开心。。。我希望能带来好运"},
							{ "people": "Amy", "num":"30","time":"2017-2-25", "postTit": "TITLE:给我烊烊的暖心小段子" ,"postCon": "你胖了，多好，这样我喜欢你的地方又多了一圈"},
							{ "people": "Abigale","num":"35", "time":"2017-2-25", "postTit": "TITLE:小王子，我在玫瑰园对你说的一世情话" ,"postCon": "小王子 我不是你的狐狸 我也不是你心爱的红玫瑰。"},
							{ "people": "Daphne","num":"45", "time":"2017-2-24", "postTit": "TITLE:说一句我们烊烊说过的话" ,"postCon": "哪有什么一夜成名，都是百炼成钢"},
							{ "people": "Fiona","num":"70", "time":"2017-2-22", "postTit": "TITLE:以岁月为弦赠你惊世情歌" ,"postCon": "我说所有的酒都不如你"},
							{ "people": "Katrina","num":"10", "time":"2017-2-20", "postTit": "TITLE:酒不醉人，你醉人" ,"postCon": "风花雪月皆可负，唯你不可。"}]}
	var posttwo =  { "content":[{ "people": "Amanda","num":"50", "time":"2017-2-19", "postTit": "TITLE:我想为你唱首歌" ,"postCon": "我要为你唱首歌，是你，是你，一定是你。"},
							{ "people": "Corrine", "num":"55","time":"2017-2-19", "postTit": "TITLE:不问山高和地远" ,"postCon": "知道吗，我总是惦记，十五岁不快乐的你"},
							{ "people": "Daphne","num":"34", "time":"2017-2-18", "postTit": "TITLE:宠爱着你" ,"postCon": "小小的年纪，还不懂什么是爱，却被你甜甜的笑给打败"},
							{ "people": "Ella","num":"44", "time":"2017-2-18", "postTit": "TITLE:Too young ,too simple" ,"postCon": "小路旁，依旧安然无恙，依旧人来人往，上台又散场"},
							{ "people": "Irene","num":"78", "time":"2017-2-16", "postTit": "TITLE:以岁月为弦赠你惊世情歌" ,"postCon": "我怎么变这样，变得这样疯狂"},
							{ "people": "Jamie","num":"17", "time":"2017-2-16", "postTit": "TITLE:酒不醉人，你醉人" ,"postCon": "每一步的地方，每一站都不会忘"}]}
							
	for(var i=0;i<6;i++){
		str+='<div id="bbsmaskcontent"  >'
				+ '<div id="num">'
					+'<span id="bbsmaskcontentnumword">'
						+post.content[i].num
					+'</span>'
				+'</div>'
				+'<div id="bbsmaskcontentword">'
					+'<span id="wordtitle">'
						+post.content[i].postTit
					+'</span>'
					+'<span id="name">'
						+post.content[i].people
					+'</span>'+'<br/>'+'<br/>'
					+'<span id="wordcon">'
					+post.content[i].postCon
					+'</span>'
					+'<span id="time">'
							+post.content[i].time
					+'</span>'
				+'</div>'
			+'</div>';
	}
	$("#bbsmaskcon").append(str);
	var Jstr = "";
	for(var j=0;j<6;j++){
		Jstr+='<div id="bbsmaskcontenttwo" class="none">'
				+ '<div id="num">'
					+'<span id="bbsmaskcontentnumword">'
						+posttwo.content[j].num
					+'</span>'
				+'</div>'
				+'<div id="bbsmaskcontentword">'
					+'<span id="wordtitle">'
						+posttwo.content[j].postTit
					+'</span>'
					+'<span id="name">'
						+posttwo.content[j].people
					+'</span>'+'<br/>'+'<br/>'
					+'<span id="wordcon">'
					+posttwo.content[j].postCon
					+'</span>'
					+'<span id="time">'
							+posttwo.content[j].time
					+'</span>'
				+'</div>'
			+'</div>';
			
			
		}$("#bbsmaskcon").append(Jstr);
	}
	showJSON();		

	// 按钮
	$("#first").click(function(){
		$("#bbsmaskcontenttwo").addClass("none");
		$("#bbsmaskcontent").removeClass("none");
	});
	$("#second").click(function(){
		$("#bbsmaskcontenttwo").addClass("none");
		$("#bbsmaskcontent").removeClass("none");
	});
	$("#next").click(function(){
		$("#bbsmaskcontent").addClass("none");
		$("#bbsmaskcontenttwo").removeClass("none");
	});
	$("#last").click(function(){
		$("#bbsmaskcontent").addClass("none");
		$("#bbsmaskcontenttwo").removeClass("none");
	});
});
